const express = require('express');
const router = express.Router();
router.get('/create', (req, res)=>{
	res.render('view.ejs')
});

module.exports = router