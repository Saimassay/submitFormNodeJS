var fs = require("fs");
// var savPath = "output.txt";
// var srcPath = "input.txt";
// var data = "Hello World";
// fucntion getData(savPath, srcPath){
// fs.read(srcPath, function(err,data){
// 	if (err) throw err;
// 	fs.writeFile(savPath, data, function(err){
// 		if (err) throw err;
// 		console.log('complete');

// 	});
// });

// }
//var text = Object.create(null);	
let text = fs.readFileSync("input.txt");


var data = "Hello World";

fs.writeFile("output.txt", text+data, (err)=>{
	if (err) console.log(err);
	console.log("get it");

});
